# Going live on GoDaddy — no Replit, no build

Everything in the `site/` folder is the whole website. Two files:

- `index.html`
- `headshot.png`

## Upload

1. GoDaddy → My Products → your Web Hosting → **cPanel Admin**
2. Open **File Manager**
3. Go into the `public_html` folder
4. Delete or rename whatever is in there now (keep a copy first)
5. Upload both `index.html` and `headshot.png` into `public_html` — same folder, not a subfolder
6. Visit zacharybest.com

That's it. No build step, no deploy, no server.

If GoDaddy is only your domain registrar (no Web Hosting product listed), tell me
and I'll give you the free-hosting route instead — GitHub Pages or Netlify will
serve these two files at zacharybest.com by changing your DNS.

## What to tell Replit

Nothing is required — you can just stop using it. If you want to shut it down
cleanly, delete or archive the Repl. The API server and Postgres database were
only there for the old contact form, which this page doesn't have.

The GitHub repo can stay as a record. It no longer feeds the live site.

## Editing later

`index.html` is plain HTML — open it in any text editor. Text lives near the
bottom, colors and sizes in the `<style>` block at the top. To change the photo,
replace `headshot.png` with any image of the same name (4:5 portrait crop works
best).
